# Music Player

A music player built with **HTMLAudioElement** API and custom design.

## Project Specifications

+ Custom UI
+ Song cover and other details are displayed
+ Play and Pause
+ Switch between songs

